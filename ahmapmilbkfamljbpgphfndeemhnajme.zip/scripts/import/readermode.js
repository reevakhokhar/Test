var elementHelperbird = document.documentElement;
var isFullScreen = false;
/* View in fullscreen */
function openFullscreen() {
	if (elementHelperbird.requestFullscreen) {
		elementHelperbird.requestFullscreen();
	} else if (elementHelperbird.mozRequestFullScreen) {
		/* Firefox */
		elementHelperbird.mozRequestFullScreen();
	} else if (elementHelperbird.webkitRequestFullscreen) {
		/* Chrome, Safari and Opera */
		elementHelperbird.webkitRequestFullscreen();
	} else if (elementHelperbird.msRequestFullscreen) {
		/* IE/Edge */
		elementHelperbird.msRequestFullscreen();
	}
	isFullScreen = true;
}

function closeReadermode(id) {
	let ids = ['helperbird-reader-id', 'helperbird-reader'];
	ids.forEach((value, index) => {
		const ELEM = document.getElementById(value);
		if (ELEM) {
			ELEM.remove();
		}
	});
}

/* Close fullscreen */
function closeFullscreen() {
	if (document.exitFullscreen) {
		document.exitFullscreen();
	} else if (document.mozCancelFullScreen) {
		/* Firefox */
		document.mozCancelFullScreen();
	} else if (document.webkitExitFullscreen) {
		/* Chrome, Safari and Opera */
		document.webkitExitFullscreen();
	} else if (document.msExitFullscreen) {
		/* IE/Edge */
		document.msExitFullscreen();
	}
	isFullScreen = false;
}
